module CVW

go 1.24.0

toolchain go1.24.1

// toolchain go1.24

require golang.org/x/tools v0.42.0

require (
	golang.org/x/mod v0.33.0 // indirect
	golang.org/x/sync v0.19.0 // indirect
)
